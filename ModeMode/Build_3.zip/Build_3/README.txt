WASD - Move
Space - Dash
Right MB - Shoot
Left MB - Shoot Capsule

Capsules capture enemies and give you a powerup
Currently the only enemies that work are:
Gold Key
Alarm
Pink Flower
White flower